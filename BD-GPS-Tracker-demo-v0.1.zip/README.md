# BD-GPS-Tracker Demo v0.1

## What works
- Interactive map (OpenStreetMap)
- Uses this phone/browser's real GPS after the user grants permission
- Shows latitude, longitude, accuracy, speed (when available), timestamp
- Shows a recent location trail while the page remains open
- Responsive website for mobile and desktop

## Important limitations
- This is a front-end prototype. It does not yet send locations to Firebase or share them with other users.
- Demo Vehicle 01 is a sample marker, not a real vehicle.
- A separate GPS tracker device requires hardware/protocol integration.
- GPS requires HTTPS and user permission. GitHub Pages provides HTTPS.
- Do not track anyone without their informed consent.

## Publish with GitHub Pages
1. Extract this ZIP.
2. Upload `index.html` and `README.md` to the root of your existing `BD-GPS-Tracker` GitHub repository.
3. In GitHub, open Settings -> Pages.
4. Set Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Open the published Pages URL on your Android phone and tap "আমার GPS চালু করুন".
